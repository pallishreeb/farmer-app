const TokenObj = {
    BuyerToken :"",
    FarmerToken:"",
}

module.exports = TokenObj