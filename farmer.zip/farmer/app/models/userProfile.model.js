// const mongoose = require('mongoose');

// const userProfileSchema = mongoose.Schema({
//     fullname:{type:String,require:true},
//     profile:{type:Array,require:true},
//     farmer_id:{
//         type:mongoose.Schema.Types.ObjectId,
//         ref: "admin",
//     }
// }, {
//     timestamps: true
// });

// module.exports = mongoose.model('userprofile', userProfileSchema);