module.exports = {
   url: 'mongodb+srv://farmerDeveloper:asdf1234@cluster0.vdqtb.mongodb.net/farmer-update?retryWrites=true&w=majority'
}
