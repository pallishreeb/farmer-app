module.exports = {
  'secret': 'supersecret',

};